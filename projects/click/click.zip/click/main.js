function game(element){
    var red = document.querySelector('.targetRed');
    red.style.display = 'block';
    element.style.display = 'none';
}
function next(element){
    var x = document.querySelector('.targetGreen-2');
    x.style.display = 'block';
    element.style.display = 'none';
}
function next2(element){
    var x = document.querySelector('.targetBlue-2');
    x.style.display = 'block';
    element.style.display = 'none';
}
function next3(element){
    var x = document.querySelector('.targetGreen');
    x.style.display = 'block';
    element.style.display = 'none';
}
function next4(element){
    var x = document.querySelector('.targetRed-2');
    x.style.display = 'block';
    element.style.display = 'none';
}
function next5(element){
    var x = document.querySelector('.targetBlue');
    x.style.display = 'block';
    element.style.display = 'none';
}
function next6(element){
    var x = document.querySelector('#restart');
    x.style.display = 'block';
    element.style.display = 'none';
}
function restart(element){
    var x = document.querySelector('#startGame');
    x.style.display = 'block';
    element.style.display = 'none';
}

