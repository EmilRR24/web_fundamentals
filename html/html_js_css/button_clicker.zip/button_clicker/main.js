function logout(element){
    element.innerText = "Logout";
}
function hide(element){
    element.remove();
}
function like(){   
    window.alert("Ninja was liked");
}
